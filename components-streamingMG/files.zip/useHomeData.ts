/**
 * hooks/useHomeData.ts
 *
 * Fetching de toutes les données de l'écran d'accueil.
 * Appels parallèles via Promise.all pour minimiser le temps de chargement.
 *
 * Routes consommées :
 *   GET /contents/featured   → HeroBanner
 *   GET /contents/trending   → Tendances
 *   GET /contents?accessType=free&limit=10  → Gratuit
 *   GET /contents?isTutorial=true&limit=10  → Derniers ajouts tutoriels
 *   GET /tutorial/progress   → Progression (si connecté)
 */

import { useState, useEffect, useCallback } from 'react';
import { apiClient } from '@/lib/apiClient';
import { useAuthStore } from '@/stores/authStore';
import type { ContentCardData } from '@/components/content/ContentCard';
import type { HeroCardData } from '@/components/content/HeroBanner';

// ─── Types ────────────────────────────────────────────────────────────────────

interface TutorialProgress {
  contentId: string;
  progressPercent: number;
}

export interface HomeData {
  featured: HeroCardData[];
  trending: ContentCardData[];
  free: ContentCardData[];
  newReleases: ContentCardData[];
  tutorialsInProgress: ContentCardData[]; // vide si non connecté
}

interface UseHomeDataReturn {
  data: HomeData | null;
  loading: boolean;
  error: string | null;
  refresh: () => void;
}

// ─── Hook ─────────────────────────────────────────────────────────────────────

export function useHomeData(): UseHomeDataReturn {
  const isAuthenticated = useAuthStore((s) => s.isAuthenticated);

  const [data, setData]       = useState<HomeData | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError]     = useState<string | null>(null);

  const fetchAll = useCallback(async () => {
    setLoading(true);
    setError(null);

    try {
      // Appels publics toujours lancés
      const publicRequests = [
        apiClient.get('/contents/featured'),
        apiClient.get('/contents/trending'),
        apiClient.get('/contents', { params: { accessType: 'free', limit: 10 } }),
        apiClient.get('/contents', { params: { limit: 10, sort: 'newest' } }),
      ];

      // Appels protégés — seulement si connecté
      const progressRequest = isAuthenticated
        ? apiClient.get('/tutorial/progress')
        : null;

      const [featuredRes, trendingRes, freeRes, newRes] =
        await Promise.all(publicRequests);

      // Fusion progression tutoriel dans les cartes si connecté
      let tutorialsInProgress: ContentCardData[] = [];

      if (progressRequest) {
        try {
          const progressRes = await progressRequest;
          const progressList: TutorialProgress[] = progressRes.data.progress ?? [];

          // On récupère les contenus en cours (progress > 0 et < 100)
          const inProgress = progressList.filter(
            (p) => p.progressPercent > 0 && p.progressPercent < 100
          );

          if (inProgress.length > 0) {
            // Fetch des détails pour chaque contenu en cours
            const detailRequests = inProgress.slice(0, 8).map((p) =>
              apiClient.get(`/contents/${p.contentId}`).then((r) => ({
                ...r.data,
                progress: p.progressPercent,
              }))
            );
            tutorialsInProgress = await Promise.all(detailRequests);
          }
        } catch {
          // Silencieux — la section est simplement masquée
        }
      }

      setData({
        featured:            featuredRes.data.featured ?? [],
        trending:            trendingRes.data.contents ?? [],
        free:                freeRes.data.contents     ?? [],
        newReleases:         newRes.data.contents      ?? [],
        tutorialsInProgress,
      });
    } catch (err: any) {
      setError('Impossible de charger le contenu. Vérifiez votre connexion.');
    } finally {
      setLoading(false);
    }
  }, [isAuthenticated]);

  useEffect(() => {
    fetchAll();
  }, [fetchAll]);

  return { data, loading, error, refresh: fetchAll };
}
