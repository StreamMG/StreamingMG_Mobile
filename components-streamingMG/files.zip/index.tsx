/**
 * app/(tabs)/index.tsx — Écran d'accueil StreamMG
 *
 * Sections :
 *  1. Header logo StreamMG
 *  2. HeroBanner (featured)
 *  3. Tendances (trending)
 *  4. Tutoriels en cours (si connecté + progression > 0)
 *  5. Gratuit
 *  6. Derniers ajouts
 *
 * AccessGateModal est dans _layout.tsx — pas ici.
 */

import React, { useCallback } from 'react';
import {
  View,
  Text,
  FlatList,
  ScrollView,
  RefreshControl,
  ActivityIndicator,
  TouchableOpacity,
  StyleSheet,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { router } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';

import { HeroBanner }    from '@/components/content/HeroBanner';
import { ContentCard }   from '@/components/content/ContentCard';
import type { ContentCardData } from '@/components/content/ContentCard';
import type { HeroCardData }    from '@/components/content/HeroBanner';
import { SectionHeader } from '@/components/ui/SectionHeader';

import { useHomeData }   from '@/hooks/useHomeData';
import { useAuthStore }  from '@/stores/authStore';
import { colors }        from '@/lib/theme';

// ─── Constantes ───────────────────────────────────────────────────────────────

const CARD_WIDTH         = 140;
const CARD_HORIZONTAL_GAP = 10;
const SECTION_MARGIN_BOTTOM = 28;

// ─── Composant ────────────────────────────────────────────────────────────────

export default function HomeScreen() {
  const { data, loading, error, refresh } = useHomeData();
  const isAuthenticated = useAuthStore((s) => s.isAuthenticated);

  // ── Navigations ──────────────────────────────────────────────────────────────

  const handleCardPress = useCallback((item: ContentCardData) => {
    router.push(`/content/${item._id}`);
  }, []);

  const handleHeroWatch = useCallback((item: HeroCardData) => {
    router.push(`/player/${item._id}`);
  }, []);

  const handleHeroInfo = useCallback((item: HeroCardData) => {
    router.push(`/content/${item._id}`);
  }, []);

  const handleSeeAll = useCallback((section: string) => {
    router.push(`/explorer?section=${section}`);
  }, []);

  // ── États ────────────────────────────────────────────────────────────────────

  if (loading) {
    return (
      <SafeAreaView style={s.loadingContainer}>
        <ActivityIndicator size="large" color={colors.primary} />
      </SafeAreaView>
    );
  }

  if (error) {
    return (
      <SafeAreaView style={s.loadingContainer}>
        <Ionicons name="wifi-outline" size={48} color={colors.textMuted} style={{ opacity: 0.4 }} />
        <Text style={s.errorText}>{error}</Text>
        <TouchableOpacity style={s.retryButton} onPress={refresh}>
          <Text style={s.retryText}>Réessayer</Text>
        </TouchableOpacity>
      </SafeAreaView>
    );
  }

  if (!data) return null;

  const heroItem = data.featured[0] ?? null;

  // ── Rendu ────────────────────────────────────────────────────────────────────

  return (
    <SafeAreaView style={s.root} edges={['top']}>
      <ScrollView
        style={s.scroll}
        showsVerticalScrollIndicator={false}
        refreshControl={
          <RefreshControl
            refreshing={loading}
            onRefresh={refresh}
            tintColor={colors.primary}
            colors={[colors.primary]}
          />
        }
      >
        {/* ── Logo ── */}
        <View style={s.header}>
          <Text style={s.logo}>
            Stream<Text style={s.logoAccent}>MG</Text>
          </Text>
        </View>

        {/* ── HeroBanner ── */}
        {heroItem && (
          <View style={{ marginBottom: SECTION_MARGIN_BOTTOM }}>
            <HeroBanner
              item={heroItem}
              onWatch={handleHeroWatch}
              onInfo={handleHeroInfo}
            />
          </View>
        )}

        {/* ── Tendances ── */}
        {data.trending.length > 0 && (
          <View style={{ marginBottom: SECTION_MARGIN_BOTTOM }}>
            <SectionHeader
              title="Tendances"
              onSeeAll={() => handleSeeAll('trending')}
            />
            <HorizontalCardList
              data={data.trending}
              onPress={handleCardPress}
            />
          </View>
        )}

        {/* ── Tutoriels en cours — connecté uniquement ── */}
        {isAuthenticated && data.tutorialsInProgress.length > 0 && (
          <View style={{ marginBottom: SECTION_MARGIN_BOTTOM }}>
            <SectionHeader title="Tutoriels en cours" />
            <HorizontalCardList
              data={data.tutorialsInProgress}
              onPress={handleCardPress}
            />
          </View>
        )}

        {/* ── Gratuit ── */}
        {data.free.length > 0 && (
          <View style={{ marginBottom: SECTION_MARGIN_BOTTOM }}>
            <SectionHeader
              title="Gratuit"
              onSeeAll={() => handleSeeAll('free')}
            />
            <HorizontalCardList
              data={data.free}
              onPress={handleCardPress}
            />
          </View>
        )}

        {/* ── Derniers ajouts ── */}
        {data.newReleases.length > 0 && (
          <View style={{ marginBottom: SECTION_MARGIN_BOTTOM + 16 }}>
            <SectionHeader
              title="Derniers ajouts"
              onSeeAll={() => handleSeeAll('new')}
            />
            <HorizontalCardList
              data={data.newReleases}
              onPress={handleCardPress}
            />
          </View>
        )}
      </ScrollView>
    </SafeAreaView>
  );
}

// ─── HorizontalCardList ───────────────────────────────────────────────────────

interface HorizontalCardListProps {
  data: ContentCardData[];
  onPress: (item: ContentCardData) => void;
}

function HorizontalCardList({ data, onPress }: HorizontalCardListProps) {
  return (
    <FlatList
      data={data}
      keyExtractor={(item) => item._id}
      horizontal
      showsHorizontalScrollIndicator={false}
      contentContainerStyle={{
        paddingHorizontal: 16,
        gap: CARD_HORIZONTAL_GAP,
      }}
      renderItem={({ item }) => (
        <ContentCard
          item={item}
          width={CARD_WIDTH}
          onPress={onPress}
        />
      )}
      // Perf
      removeClippedSubviews
      initialNumToRender={5}
      maxToRenderPerBatch={5}
      windowSize={3}
    />
  );
}

// ─── Styles ───────────────────────────────────────────────────────────────────

const s = StyleSheet.create({
  root: {
    flex: 1,
    backgroundColor: colors.bgBase,
  },
  scroll: {
    flex: 1,
  },
  header: {
    paddingHorizontal: 16,
    paddingTop: 8,
    paddingBottom: 16,
  },
  logo: {
    fontSize: 22,
    color: colors.textPrimary,
    fontFamily: 'Sora_800ExtraBold',
    letterSpacing: -0.5,
  },
  logoAccent: {
    color: colors.primary,
  },
  loadingContainer: {
    flex: 1,
    backgroundColor: colors.bgBase,
    alignItems: 'center',
    justifyContent: 'center',
    gap: 16,
  },
  errorText: {
    fontSize: 14,
    color: colors.textSecond,
    fontFamily: 'DMSans_400Regular',
    textAlign: 'center',
    paddingHorizontal: 32,
  },
  retryButton: {
    paddingHorizontal: 24,
    paddingVertical: 10,
    borderRadius: 20,
    backgroundColor: 'rgba(53,132,228,0.15)',
    borderWidth: 1,
    borderColor: 'rgba(53,132,228,0.3)',
  },
  retryText: {
    color: colors.primary,
    fontFamily: 'DMSans_500Medium',
    fontSize: 14,
  },
});
